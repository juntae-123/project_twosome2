import Title from "@/ES/common/Title";

const FranchiseTitle = () => {
  return <Title title={"FRANCHISE"} ismore={true} />;
};

export default FranchiseTitle;
